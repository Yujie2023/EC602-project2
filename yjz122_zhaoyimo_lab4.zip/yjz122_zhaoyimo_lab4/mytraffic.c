#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h> /* printk() */
#include <linux/slab.h> /* kmalloc() */
#include <linux/fs.h> /* everything... */
#include <linux/errno.h> /* error codes */
#include <linux/types.h> /* size_t */
#include <linux/proc_fs.h>
#include <linux/fcntl.h> /* O_ACCMODE */
#include <linux/jiffies.h>
#include <asm/system_misc.h> /* cli(), *_flags */
#include <linux/uaccess.h>
#include <asm/uaccess.h> /* copy_from/to_user */
#include <linux/timer.h>
#include <linux/sched.h>
#include <linux/gpio.h>
#include <linux/interrupt.h>

MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("yjz122_zhaoyimo");

/*Setting Up the BeagleBone Black's GPIO Pins*/
#define redlight 67
#define yellowlight 68
#define greenlight 44
#define btn0 26
#define btn1 46

/*Function declarations*/
static int mytraffic_init(void);
static void mytraffic_exit(void);
static ssize_t mytraffic_read(struct file *filp, char *buf, size_t count, loff_t *f_pos);
static ssize_t mytraffic_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos);
static int mytraffic_open(struct inode *inode, struct file *filp);
static int mytraffic_release(struct inode *inode, struct file *filp);


/*file operations*/
struct file_operations mytraffic_fops = {
	read: mytraffic_read,
	write: mytraffic_write,
	open: mytraffic_open,
	release: mytraffic_release
};

static struct timer_list mytimer;

/* Declaration of the init and exit functions */
module_init(mytraffic_init);
module_exit(mytraffic_exit);
const unsigned user_input_capacity = 256;
const unsigned user_output_capacity = 1024;
static unsigned bite = 256;
// Global variables 
static const int mytraffic_major = 61;

// Buffer to store data from user
static char *user_input;

// Buffer to store data to send to user
static char *user_output;

/*sevral flags*/
static int mode = 0;
static int step = 0;
static int flash_switch = 0;
static int ped_cross = 0;//volatile
static int time_base = 1;


static irqreturn_t btn0_handler(int irq, void *dev_id)
{
    if (mode < 2) 
	{
        mode +=1;
    	} 
   else if(mode == 2)
	{
        mode = 0;
    	}
   else
	{
	printk(KERN_ERR "mode error");
	}
	

    return IRQ_HANDLED;
}

static irqreturn_t btn1_handler(int irq, void *dev_id)
{

    ped_cross = 1;
    return IRQ_HANDLED;
}

void mytraffic_handler(struct timer_list *timer)
{
    
  if (mode == 0) 						// Normal mode
  {
        if(step==0) 
	{
            gpio_set_value(greenlight, 1);     
            gpio_set_value(yellowlight, 0);     
            gpio_set_value(redlight, 0);        
            mod_timer(&mytimer, jiffies + msecs_to_jiffies(3000/time_base));
            step += 1;
        } 
	else if(step==1)
	{
            gpio_set_value(greenlight, 0);      
            gpio_set_value(yellowlight, 1);    
            gpio_set_value(redlight, 0);       
            mod_timer(&mytimer, jiffies + msecs_to_jiffies(1000/time_base));
            step += 1;
        } 
	else if (step== 2) 
	{
            	if (ped_cross == 1)                   //first check if press button 1 :red&yellow 5 sec
		{
                	gpio_set_value(greenlight, 0);      
            		gpio_set_value(yellowlight, 1);    
            		gpio_set_value(redlight, 1);
			mod_timer(&mytimer, jiffies + msecs_to_jiffies(5000/time_base));
                	ped_cross = 0;
                	step = 0;
            	} 
		else if(ped_cross ==0)               //not press btn1 : red 2sec               
		{
                	gpio_set_value(greenlight, 0);      
            		gpio_set_value(yellowlight, 0);    
            		gpio_set_value(redlight, 1);     
                	mod_timer(&mytimer, jiffies + msecs_to_jiffies(2000/time_base));
                	step = 0;
            	}
        }
  } 
  else if (mode == 1)                             //flashing red mode
  {       
        if (flash_switch==0)                                         //on
	{
            gpio_set_value(greenlight, 0);      
            gpio_set_value(yellowlight, 0);    
            gpio_set_value(redlight, 1);
            mod_timer(&mytimer, jiffies + msecs_to_jiffies(1000/time_base));
            flash_switch = 1;
        } 
	else if(flash_switch==1)                                    //off
	{
            gpio_set_value(greenlight, 0);     
            gpio_set_value(yellowlight, 0);     
            gpio_set_value(redlight, 0); 
            mod_timer(&mytimer, jiffies + msecs_to_jiffies(1000/time_base));
            flash_switch = 0;
        }
} 
else if (mode == 2)       			// flashing yellow mode
{ 
        if (flash_switch==0) 
	{
            gpio_set_value(greenlight, 0);      
            gpio_set_value(yellowlight, 1);    
            gpio_set_value(redlight, 0);
            mod_timer(&mytimer, jiffies + msecs_to_jiffies(1000/time_base));
            flash_switch = 1;
        } 
	else if(flash_switch==1)
	{
            gpio_set_value(greenlight, 0);      
            gpio_set_value(yellowlight, 0);    
            gpio_set_value(redlight, 0);
            mod_timer(&mytimer, jiffies + msecs_to_jiffies(1000/time_base));
            flash_switch = 0;

        }
        ped_cross = 0;
  }
}

static int __init mytraffic_init(void)
{
    int ret;
    ret = register_chrdev(mytraffic_major, "mytraffic", &mytraffic_fops);
	if (ret < 0)
	{
		printk(KERN_ALERT
			"mytraffic: cannot obtain major number %d\n", mytraffic_major);
		return ret;
	}
	user_input = kmalloc(user_input_capacity, GFP_KERNEL); 
	if (!user_input)
	{ 
		printk(KERN_ALERT "Insufficient kernel memory\n"); 
		ret = -ENOMEM;
		goto fail; 
	} 
	memset(user_input, 0, user_input_capacity);
	/* Allocating mytraffic for the buffer */
	user_output = kmalloc(user_output_capacity, GFP_KERNEL); 
	if (!user_output)
	{ 
		printk(KERN_ALERT "Insufficient kernel memory\n"); 
		ret = -ENOMEM;
		goto fail; 
	} 
	memset(user_output, 0, user_output_capacity);
		/*INITIALIZE GPIO*/
    ret = gpio_request(greenlight, "mytraffic-green");
    if (ret < 0) {
        printk(KERN_ERR "failed to interact with gpio: %d\n", greenlight);
        return ret;
    }
    ret = gpio_direction_output(greenlight, 1);
    if (ret < 0) {
        printk(KERN_ERR "failed to interact with gpio: %d\n", greenlight);
        gpio_free(greenlight);
        return ret;
    } 
    ret = gpio_request(yellowlight, "mytraffic-yellow");
    if (ret < 0) {
        printk(KERN_ERR "Failed to request GPIO %d\n",yellowlight);
        return ret;
    }
    ret = gpio_direction_output(yellowlight, 1);
    if (ret < 0) {
        printk(KERN_ERR "Failed to set GPIO %d direction\n", yellowlight);
        gpio_free(yellowlight);
        return ret;
    } 
    ret = gpio_request(redlight, "mytraffic-red");
    if (ret < 0) {
        printk(KERN_ERR "Failed to request GPIO %d\n", redlight);
        return ret;
    }
    ret = gpio_direction_output(redlight, 1);

    if (ret < 0) {
        printk(KERN_ERR "Failed to set GPIO %d direction\n", redlight);
        gpio_free(redlight);
        return ret;
    }  

	/*two button init*/
    if (!gpio_is_valid(btn0)) 
	{
        printk(KERN_INFO "Invalid GPIO pin %d\n", btn0);
        return -ENODEV;
    	}
    	ret = gpio_request(btn0, "mytraffic-BTN");
    if (ret < 0) 
	{
        printk(KERN_INFO "Failed to request GPIO pin %d\n", btn0);
        return ret;
    	}
    	ret = gpio_direction_input(btn0);
    if (ret < 0) {
        printk(KERN_INFO "Failed to set GPIO pin %d as input\n", btn0);
        gpio_free(btn0);
        return ret;
    }
    ret = request_irq(gpio_to_irq(btn0), (irq_handler_t)btn0_handler, IRQF_TRIGGER_FALLING, "mytraffic_irq_zero", NULL);
    if (ret < 0) {
        printk(KERN_INFO "Failed to request interrupt for GPIO pin %d\n", btn0);
        gpio_free(btn0);
        return ret;
    }

    if (!gpio_is_valid(btn1)) 
	{
        printk(KERN_INFO "Invalid GPIO pin %d\n", btn1);
        return -ENODEV;
    	}
    	ret = gpio_request(btn1, "mytraffic-BTN");
    if (ret < 0) 
	{
        printk(KERN_INFO "Failed to request GPIO pin %d\n", btn1);
        return ret;
    	}
    	ret = gpio_direction_input(btn1);
    if (ret < 0) {
        printk(KERN_INFO "Failed to set GPIO pin %d as input\n", btn1);
        gpio_free(btn1);
        return ret;
    }
    ret = request_irq(gpio_to_irq(btn1), (irq_handler_t)btn1_handler, IRQF_TRIGGER_FALLING, "mytraffic_irq_one", NULL);
    if (ret < 0) {
        printk(KERN_INFO "Failed to request interrupt for GPIO pin %d\n", btn1);
        gpio_free(btn1);
        return ret;
    }

    
    // Setup Timer
    timer_setup(&mytimer, mytraffic_handler, 0);
    mod_timer(&mytimer, jiffies + msecs_to_jiffies(1));

    return 0;

fail: 
	mytraffic_exit(); 
	return ret;
}
static ssize_t mytraffic_read(struct file *filp, char *buf, size_t count, loff_t *f_pos)
{ 
	char*var = user_output;
	int temp;
	char tbuf[256], *tbptr = tbuf;
	var += sprintf(var,"Mode: %s\nCycle rate: %d Hz\nLight status: green %s, yellow %s, red %s\nPedestrian present: %s\n",
	    mode == 0 ? "normal" : mode == 1 ? "flashing-red" : "flashing-yellow",
            time_base,
            gpio_get_value(greenlight) ? "on" : "off",
            gpio_get_value(yellowlight) ? "on" : "off",
            gpio_get_value(redlight) ? "on" : "off",
            ped_cross ? "yes" : "no");
        unsigned int mytraffic_len = strlen(user_output);
	/* end of buffer reached */
	if (*f_pos >= mytraffic_len)
	{
		return 0;
	}
	/* do not go over then end */
	if (count > mytraffic_len - *f_pos)
		count = mytraffic_len - *f_pos;

	/* do not send back more than a bite */
	if (count > bite) count = bite;
	/* Transfering data to user space */ 
	if (copy_to_user(buf, user_output + *f_pos, count))
	{
		return -EFAULT;
	}
	tbptr += sprintf(tbptr,								   
		"read called: process id %d, command %s, count %d, chars ",
		current->pid, current->comm, count);

	for (temp = *f_pos; temp < count + *f_pos; temp++)					  
		tbptr += sprintf(tbptr, "%c", user_output[temp]);
	printk(KERN_INFO "%s\n", tbuf);
	// Reset output buffer
	strcpy(user_output, "");
	return count; 
}

static ssize_t mytraffic_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos)
{
    uint temp;
    char tbuf[256], *tbptr = tbuf;
    // char registerTimerBuffer[256];
    unsigned int num;
    
    // end of buffer reached
    if (*f_pos >= user_input_capacity) {
        return -ENOSPC;
    }
    
    /* do not eat more than a bite*/
    if (count > bite) {
        count = bite;
    }
    
    /* do not go over the end*/
    if (count > user_input_capacity - *f_pos) {
        count = user_input_capacity - *f_pos;
    } 
    
      // copy data from user
    memset(user_input, 0, user_input_capacity);
    if (copy_from_user(user_input + *f_pos, buf, count)) {
        return -EFAULT;
    }
    
    // print debug information
    tbptr += sprintf(tbptr, "write called: process id %d, command %s, count %d, offset %lld, chars ",
                     current->pid, current->comm, count, *f_pos);
    for (temp = *f_pos; temp < count + *f_pos; temp++) {
        tbptr += sprintf(tbptr, "%c", user_input[temp]);
    }
    
    
    if (kstrtouint(user_input, 10, &num) < 0) {
        printk(KERN_ERR "error converting\n");
        return -EINVAL;
    }
    
    time_base=num;
    
    return count;
}
static void __exit mytraffic_exit(void)
{   
    	unregister_chrdev(mytraffic_major, "mytraffic");
	if (user_input)
	{
		kfree(user_input);
	}

	if(user_output) 
	{
		kfree(user_output);
	}
    	
   	gpio_free(greenlight);
    	gpio_free(yellowlight);
    	gpio_free(redlight);
    	free_irq(gpio_to_irq(btn0_handler), NULL);
    	gpio_free(btn0_handler);
    	free_irq(gpio_to_irq(btn1_handler), NULL);
    	gpio_free(btn1_handler);
	del_timer(&mytimer);
    	printk(KERN_INFO "exit mytraffic\n");
}

static int mytraffic_open(struct inode *inode, struct file *filp)
{	
	return 0;
}

static int mytraffic_release(struct inode *inode, struct file *filp)
{
	return 0;
}



