Yujie Zheng 	yjz122@bu.edu
Yimo Zhao 	zhaoyimo@bu.edu

reference:
en.wikipedia.org/wiki/General-purpose_input/output
en.wikipedia.org/wiki/Interrupt
en.wikipedia.org/wiki/Serial_port
learn.sparkfun.com/tutorials/how-to-use-a-breadboard/
